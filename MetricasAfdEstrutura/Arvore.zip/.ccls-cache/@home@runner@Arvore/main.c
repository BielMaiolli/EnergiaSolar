#include <stdio.h>
#include <stdlib.h>

// Definição da estrutura de um nó da árvore binária
struct Node {
    int data;
    struct Node* left;
    struct Node* right;
};

// Função para criar um novo nó
struct Node* newNode(int data) {
    struct Node* node = (struct Node*)malloc(sizeof(struct Node));
    node->data = data;
    node->left = NULL;
    node->right = NULL;
    return node;
}

// Função para inserir um novo nó na árvore binária
struct Node* insert(struct Node* node, int data) {
    if (node == NULL) {
        return newNode(data);
    }

    if (data < node->data) {
        node->left = insert(node->left, data);
    } else if (data > node->data) {
        node->right = insert(node->right, data);
    }

    return node;
}

// Função para percorrer a árvore em ordem (in-order)
void inOrder(struct Node* root) {
    if (root != NULL) {
        inOrder(root->left);
        printf("%d ", root->data);
        inOrder(root->right);
    }
}

// Função para percorrer a árvore em pré-ordem (pre-order)
void preOrder(struct Node* root) {
    if (root != NULL) {
        printf("%d ", root->data);
        preOrder(root->left);
        preOrder(root->right);
    }
}

// Função para percorrer a árvore em pós-ordem (post-order)
void postOrder(struct Node* root) {
    if (root != NULL) {
        postOrder(root->left);
        postOrder(root->right);
        printf("%d ", root->data);
    }
}

// Função principal para demonstrar a criação e a travessia da árvore
int main() {
    struct Node* root = NULL;
    root = insert(root, 1000);
    insert(root, 1211);
    insert(root, 1020);
    insert(root, 0300);
    insert(root, 3200);
    insert(root, 0000);
    insert(root, 0203);

    printf("Percurso em ordem (in-order): ");
    inOrder(root);
    printf("\n");

    printf("Percurso em pré-ordem (pre-order): ");
    preOrder(root);
    printf("\n");

    printf("Percurso em pós-ordem (post-order): ");
    postOrder(root);
    printf("\n");

    return 0;
}